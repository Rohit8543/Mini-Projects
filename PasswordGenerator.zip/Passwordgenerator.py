import sys
import string
import random
from PyQt5.QtCore  import Qt
from PyQt5.QtWidgets import QApplication,QWidget,QLabel,QTextEdit,QPushButton,QMessageBox,QLineEdit
from PyQt5.QtGui import QFont,QIntValidator
class passwordgnr(QWidget):
    def __init__(self):
        super().__init__()
        self.initui()
    
    
    def initui(self):
        self.setWindowTitle("Password Generator")  
        self.setGeometry(0,0,600,400)
        self.setStyleSheet("background-color:lightblue; color:black;")
        
        
        self.title_label=QLabel("Password Generator",self)
        self.title_label.setGeometry(150,0,300,130)
        self.title_label.setFont(QFont("Arial",17))

        
        self.length_label=QLabel("Length of the Password: ",self)
        self.length_label.setGeometry(20,120,300,25)
        
        
        
        self.length_textbox = QLineEdit(self)
        validator = QIntValidator()  # Create an integer validator
        self.length_textbox.setValidator(validator)  # Set the validator to the QLineEdit
        self.length_textbox.setGeometry(150,120,60,25)
                 
        
        self.passwordgen=QLabel("",self)
        self.passwordgen.setGeometry(120,180,280,40)
        self.passwordgen.setFont(QFont("Arial",19))
        self.passwordgen.setStyleSheet("border:1px solid black; padding: 5px;")
        
        self.passwordbtn=QPushButton("Generate",self)
        self.passwordbtn.setGeometry(120,270,280,60)
        self.passwordbtn.setStyleSheet('''
            QPushButton {
                background-color: #A9A9A9;
                color: white;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #808080;
            }
        ''')
        self.passwordbtn.clicked.connect(self.generate_password)
        
        self.copy_btn = QPushButton("Copy", self)
        self.copy_btn.setGeometry(350, 190, 70, 25)
        self.copy_btn.clicked.connect(self.copy_password)
        self.copy_btn.setStyleSheet("background-color:none; color:black; border:none")
        
        
    def copy_password(self):
        password = self.passwordgen.text()
        if password:
            clipboard = QApplication.clipboard()
            clipboard.setText(password)
            QMessageBox.information(self, "Password Copied", "Password copied to clipboard!")
        else:
            QMessageBox.warning(self, "Warning", "No password generated yet.")
            
            
    def generate_password(self):
        password_length_text = self.length_textbox.text()
        if not password_length_text:
            QMessageBox.warning(self, "Warning", "Please enter the length of the password.")
            return
        
        password_length = int(password_length_text)
        if password_length <= 0:
            QMessageBox.warning(self, "Warning", "Please enter a valid password length.")
            return
        
        
        def generate_password1(length):
            uppercase_letters = string.ascii_uppercase
            lowercase_letters = string.ascii_lowercase
            digits = string.digits
            symbols = string.punctuation

           
            password = random.choice(uppercase_letters)
            password += random.choice(lowercase_letters)
            password += random.choice(digits)
            password += random.choice(symbols)

            
            for _ in range(length - 4):  
                password += random.choice(string.ascii_letters + string.digits + string.punctuation)

           
            password_list = list(password)
            random.shuffle(password_list)
            return ''.join(password_list)
        
        
        fake_password = generate_password1(password_length)
        
        # Display generated password
        self.passwordgen.setText(fake_password)
        
        
if __name__=="__main__":
    app=QApplication(sys.argv)
    GeneratorP=passwordgnr()
    GeneratorP.show()
    sys.exit(app.exec_())
    