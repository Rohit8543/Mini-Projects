from PyQt5.QtWidgets import QApplication, QWidget, QLabel,QPushButton
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt
import sys
import random
class RPS(QWidget):  # Change inheritance to QWidget
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setWindowTitle('Rock Paper Scissor')
        self.setGeometry(50, 50, 600, 400)
        self.setStyleSheet("background-color:Black")

        self.title_label = QLabel("Choose your Weapon", self)
        self.title_label.setGeometry(200, 0, 750, 60)
        self.title_label.setFont(QFont('Arial',17))
        self.title_label.setStyleSheet('color: lightblue')
  

        self.result_label = QLabel("Result: ", self)
        self.result_label.setGeometry(10, 100, 180, 40)
        self.result_label.setStyleSheet('color: yellow')
        self.result_label.setFont(QFont('Arial',20))
        
        
        self.result1_label = QLabel(self)
        self.result1_label.setGeometry(200, 100, 180, 40)
        self.result1_label.setFont(QFont('Arial',10))
        self.result1_label.setStyleSheet('color: green')
        
        
        self.result2_label=QLabel(self)
        self.result2_label.setGeometry(200,135,180,40)
        self.result2_label.setFont(QFont('Arial',10))
        self.result2_label.setStyleSheet('color: green')
        
        
        self.output_label=QLabel(self)
        self.output_label.setGeometry(200,170,180,40)
        self.output_label.setFont(QFont('Arial',14)) 
        self.output_label.setStyleSheet('color: red')
        
        self.button=QPushButton("Rock",self)
        self.button.setGeometry(0,220,180,40)
        self.button.setStyleSheet('''
            QPushButton {
                background-color: #A9A9A9;
                color: white;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #808080;
            }
        ''')
        self.button.clicked.connect(lambda: self.play_game('Rock'))
        
        self.button1=QPushButton("Paper",self)
        self.button1.setGeometry(200,220,180,40)
        self.button1.clicked.connect(lambda: self.play_game('Paper'))
        self.button1.setStyleSheet('''
            QPushButton {
                background-color: #FFD700;
                color: black;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #DAA520;
            }
        ''')
        
        
        self.scissors_button=QPushButton("Scissor",self)
        self.scissors_button.setGeometry(400,220,180,40)
        self.scissors_button.clicked.connect(lambda: self.play_game("Scissor"))
        self.scissors_button.setStyleSheet('''
            QPushButton {
                background-color: #4682B4;
                color: white;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: blue;
            }
        ''')
        
        
        
    def play_game(self, user_choice):
        game_choices = ["Rock", "Paper", "Scissors"]
        computer_choice = random.choice(game_choices)

        self.result1_label.setText(f'Your choice: {user_choice}')
        self.result2_label.setText(f'Computer choice: {computer_choice}')

        if user_choice == computer_choice:
            self.output_label.setText("It's a tie!")
        elif (user_choice == "Rock" and computer_choice == "Scissors"):
            self.output_label.setText("You win!")
        elif (user_choice == "Paper" and computer_choice == "Rock"):
            self.output_label.setText("You win!")
        elif(user_choice == "Scissors" and computer_choice == "Paper"):
            self.output_label.setText("You win!")
        else:
            self.output_label.setText("Computer wins!")

if __name__ == '__main__':
    app = QApplication(sys.argv)
    rps = RPS()
    rps.show()
    sys.exit(app.exec_())
